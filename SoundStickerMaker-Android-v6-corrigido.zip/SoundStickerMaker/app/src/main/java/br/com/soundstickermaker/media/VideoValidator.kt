package br.com.soundstickermaker.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.StatFs
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object VideoValidator {

    const val MAX_DURATION_MS = 20_000L
    private const val MIN_REQUIRED_FREE_BYTES = 20L * 1024L * 1024L

    const val ERROR_UNSUPPORTED_FORMAT =
        "Formato de vídeo não suportado. Selecione um arquivo MP4, MOV, MKV ou WebM válido."
    const val ERROR_CORRUPTED_FILE =
        "Não foi possível ler o arquivo selecionado. O vídeo pode estar corrompido."
    const val ERROR_NO_STORAGE_SPACE =
        "Espaço insuficiente no armazenamento interno do celular para processar a figurinha."

    private val SUPPORTED_VIDEO_MIMES = setOf(
        "video/avc",
        "video/hevc",
        "video/mp4v-es",
        "video/x-vnd.on2.vp8",
        "video/x-vnd.on2.vp9",
        "video/av01",
        "video/3gpp"
    )

    fun computeTargetClipDurationMs(originalDurationMs: Long): Long {
        if (originalDurationMs <= 0L) return 0L
        return minOf(originalDurationMs, MAX_DURATION_MS)
    }

    fun shouldAutoTrim(originalDurationMs: Long): Boolean {
        return originalDurationMs > MAX_DURATION_MS
    }

    suspend fun validateVideoUri(context: Context, uri: Uri): VideoValidationResult =
        withContext(Dispatchers.IO) {
            if (!hasEnoughStorageSpace(context)) {
                return@withContext VideoValidationResult.Invalid(ERROR_NO_STORAGE_SPACE)
            }

            val fileSize = queryFileSize(context, uri)
            if (fileSize == 0L) {
                return@withContext VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
            }

            val extractor = MediaExtractor()
            var hasVideo = false
            var hasAudio = false
            var videoMime = ""
            var audioMime = "Sem trilha de áudio"
            var extractorDurationMs = 0L
            var formatWidth = 0
            var formatHeight = 0
            var formatRotation = 0

            try {
                extractor.setDataSource(context, uri, null)
                val trackCount = extractor.trackCount
                if (trackCount <= 0) {
                    return@withContext VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
                }

                for (i in 0 until trackCount) {
                    val format = extractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                    if (mime.startsWith("video/") && !hasVideo) {
                        hasVideo = true
                        videoMime = mime
                        if (format.containsKey(MediaFormat.KEY_DURATION)) {
                            extractorDurationMs = format.getLong(MediaFormat.KEY_DURATION) / 1000L
                        }
                        if (format.containsKey(MediaFormat.KEY_WIDTH)) {
                            formatWidth = format.getInteger(MediaFormat.KEY_WIDTH)
                        }
                        if (format.containsKey(MediaFormat.KEY_HEIGHT)) {
                            formatHeight = format.getInteger(MediaFormat.KEY_HEIGHT)
                        }
                        if (format.containsKey(MediaFormat.KEY_ROTATION)) {
                            formatRotation = format.getInteger(MediaFormat.KEY_ROTATION)
                        }
                    } else if (mime.startsWith("audio/") && !hasAudio) {
                        hasAudio = true
                        audioMime = mime
                    }
                }
            } catch (ignored: Exception) {
                return@withContext VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
            } finally {
                runCatching { extractor.release() }
            }

            if (!hasVideo) {
                return@withContext VideoValidationResult.Invalid(ERROR_UNSUPPORTED_FORMAT)
            }

            if (videoMime.isNotBlank() && videoMime !in SUPPORTED_VIDEO_MIMES) {
                return@withContext VideoValidationResult.Invalid(ERROR_UNSUPPORTED_FORMAT)
            }

            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                val originalDurationMs = if (extractorDurationMs > 0L) {
                    extractorDurationMs
                } else {
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                        ?.toLongOrNull() ?: 0L
                }

                if (originalDurationMs <= 0L) {
                    return@withContext VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
                }

                val targetDurationMs = computeTargetClipDurationMs(originalDurationMs)
                val wasAutoTrimmed = shouldAutoTrim(originalDurationMs)

                val rawWidth = if (formatWidth > 0) formatWidth else {
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                        ?.toIntOrNull() ?: 512
                }
                val rawHeight = if (formatHeight > 0) formatHeight else {
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                        ?.toIntOrNull() ?: 512
                }
                val rotation = if (formatRotation != 0) formatRotation else {
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                        ?.toIntOrNull() ?: 0
                }

                val (effectiveWidth, effectiveHeight) = if (rotation == 90 || rotation == 270) {
                    rawHeight to rawWidth
                } else {
                    rawWidth to rawHeight
                }

                val thumbFile = extractHardwareScaledThumbnail(context, retriever)

                VideoValidationResult.Valid(
                    VideoMetadataInfo(
                        sourceUri = uri,
                        originalDurationMs = originalDurationMs,
                        targetDurationMs = targetDurationMs,
                        wasAutoTrimmed = wasAutoTrimmed,
                        width = effectiveWidth,
                        height = effectiveHeight,
                        rotationDegrees = rotation,
                        hasVideoTrack = true,
                        hasAudioTrack = hasAudio,
                        videoMimeType = videoMime,
                        audioMimeType = audioMime,
                        fileSizeBytes = fileSize,
                        previewThumbnailFile = thumbFile
                    )
                )
            } catch (ignored: Exception) {
                VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
            } finally {
                runCatching { retriever.release() }
            }
        }

    private fun hasEnoughStorageSpace(context: Context): Boolean {
        return runCatching {
            val stat = StatFs(context.filesDir.absolutePath)
            stat.availableBytes >= MIN_REQUIRED_FREE_BYTES
        }.getOrDefault(true)
    }

    private fun queryFileSize(context: Context, uri: Uri): Long {
        val afdSize = runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                afd.length
            } ?: -1L
        }.getOrDefault(-1L)

        if (afdSize > 0L) return afdSize

        return runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (idx >= 0) cursor.getLong(idx) else -1L
                } else {
                    -1L
                }
            } ?: -1L
        }.getOrDefault(-1L)
    }

    private fun extractHardwareScaledThumbnail(
        context: Context,
        retriever: MediaMetadataRetriever
    ): File? {
        return runCatching {
            val scaledBitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                retriever.getScaledFrameAtTime(
                    0L,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                    360,
                    360
                )
            } else {
                retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } ?: return null

            val cacheDir = File(context.cacheDir, "processed").apply {
                if (!exists()) mkdirs()
            }
            val thumbFile = File(cacheDir, "preview_thumb_${System.currentTimeMillis()}.jpg")
            FileOutputStream(thumbFile).use { out ->
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 78, out)
            }
            scaledBitmap.recycle()
            thumbFile
        }.getOrNull()
    }
}
