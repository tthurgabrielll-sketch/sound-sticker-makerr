package br.com.soundstickermaker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import br.com.soundstickermaker.ui.model.AppScreenRoute
import br.com.soundstickermaker.ui.screens.HomeScreen
import br.com.soundstickermaker.ui.screens.LibraryScreen
import br.com.soundstickermaker.ui.screens.PreviewScreen
import br.com.soundstickermaker.ui.screens.ProcessingScreen
import br.com.soundstickermaker.ui.screens.SettingsScreen
import br.com.soundstickermaker.ui.theme.SoundStickerMakerTheme
import br.com.soundstickermaker.ui.viewmodel.SoundStickerViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SoundStickerMakerTheme {
                val viewModel: SoundStickerViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val snackbarHostState = remember { SnackbarHostState() }

                val videoPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.PickVisualMedia()
                ) { selectedUri ->
                    if (selectedUri != null) {
                        viewModel.onVideoSelectedFromGallery(selectedUri)
                    }
                }

                LaunchedEffect(uiState.infoBannerMessage) {
                    val message = uiState.infoBannerMessage
                    if (!message.isNullOrBlank()) {
                        snackbarHostState.showSnackbar(message)
                        viewModel.dismissInfoBanner()
                    }
                }

                if (uiState.errorMessage != null) {
                    AlertDialog(
                        onDismissRequest = { viewModel.dismissError() },
                        title = { Text("Atenção") },
                        text = { Text(uiState.errorMessage.orEmpty()) },
                        confirmButton = {
                            TextButton(onClick = { viewModel.dismissError() }) {
                                Text("Entendi")
                            }
                        }
                    )
                }

                BackHandler(enabled = uiState.currentScreen != AppScreenRoute.Home) {
                    when (uiState.currentScreen) {
                        AppScreenRoute.Processing -> viewModel.cancelProcessing()
                        else -> viewModel.navigateTo(AppScreenRoute.Home)
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    when (uiState.currentScreen) {
                        AppScreenRoute.Home -> {
                            HomeScreen(
                                recentStickers = uiState.recentStickers,
                                onAddVideoClick = {
                                    videoPickerLauncher.launch(
                                        PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.VideoOnly
                                        )
                                    )
                                },
                                onOpenLibraryClick = {
                                    viewModel.navigateTo(AppScreenRoute.Library)
                                },
                                onOpenSettingsClick = {
                                    viewModel.navigateTo(AppScreenRoute.Settings)
                                },
                                onSelectSticker = { sticker ->
                                    viewModel.openSavedStickerInPreview(sticker)
                                }
                            )
                        }

                        AppScreenRoute.Processing -> {
                            ProcessingScreen(
                                thumbnailFile = uiState.processingThumbnail,
                                progress = uiState.processingProgress,
                                isAutoTrimming = uiState.isAutoTrimmingLongVideo,
                                onCancelClick = { viewModel.cancelProcessing() }
                            )
                        }

                        AppScreenRoute.Preview -> {
                            val previewItem = uiState.activePreview
                            if (previewItem != null) {
                                PreviewScreen(
                                    previewItem = previewItem,
                                    autoPlayWithSound = uiState.settings.autoPlayWithSound,
                                    isPreparingWhatsAppPack = uiState.isPreparingWhatsAppPack,
                                    onBackClick = {
                                        viewModel.navigateTo(AppScreenRoute.Home)
                                    },
                                    onAddToWhatsAppClick = {
                                        viewModel.addCurrentPreviewToWhatsApp()
                                    },
                                    onSendWithAudioClick = {
                                        viewModel.sendCurrentPreviewWithAudioToWhatsApp()
                                    },
                                    onSaveClick = {
                                        viewModel.saveCurrentPreviewToLibrary()
                                    },
                                    onShareClick = {
                                        viewModel.shareCurrentPreview()
                                    }
                                )
                            } else {
                                LaunchedEffect(Unit) {
                                    viewModel.navigateTo(AppScreenRoute.Home)
                                }
                            }
                        }

                        AppScreenRoute.Library -> {
                            LibraryScreen(
                                stickers = uiState.allStickers,
                                onBackClick = {
                                    viewModel.navigateTo(AppScreenRoute.Home)
                                },
                                onPlaySticker = { sticker ->
                                    viewModel.openSavedStickerInPreview(sticker)
                                },
                                onAddToWhatsAppPack = { sticker ->
                                    viewModel.addSavedStickerToWhatsAppPack(sticker)
                                },
                                onShareSystem = { sticker ->
                                    viewModel.shareSavedStickerSystem(sticker)
                                },
                                onDeleteSticker = { sticker ->
                                    viewModel.deleteSticker(sticker)
                                }
                            )
                        }

                        AppScreenRoute.Settings -> {
                            SettingsScreen(
                                settings = uiState.settings,
                                whatsAppSupport = uiState.whatsAppSupport,
                                onBackClick = {
                                    viewModel.navigateTo(AppScreenRoute.Home)
                                },
                                onWhatsAppTargetChange = { target ->
                                    viewModel.updateWhatsAppTarget(target)
                                },
                                onAutoPlaySoundChange = { enabled ->
                                    viewModel.updateAutoPlayWithSound(enabled)
                                },
                                onPreserveResolutionChange = { enabled ->
                                    viewModel.updatePreserveResolution(enabled)
                                },
                                onClearCacheClick = {
                                    viewModel.clearCache()
                                }
                            )
                        }
                    }

                    SnackbarHost(
                        hostState = snackbarHostState,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                    )
                }
            }
        }
    }
}
