package br.com.soundstickermaker.stickers

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.os.Build
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Codificador rápido de figurinhas animadas WebP (512x512 px, < 460 KB)
 * em conformidade com a especificação oficial de pacotes de figurinhas do WhatsApp.
 */
object AnimatedWebpEncoder {

    const val STICKER_CANVAS_SIZE = 512
    const val TRAY_ICON_SIZE = 96
    private const val MAX_WHATSAPP_ANIMATED_BYTES = 460 * 1024

    /**
     * Gera um arquivo .webp animado 512x512 em menos de 300ms a partir do clipe de vídeo.
     */
    fun encodeVideoToAnimatedWebp(
        videoFile: File,
        durationMs: Long,
        outputWebpFile: File,
        fallbackThumbnailFile: File? = null
    ): Boolean {
        val frames = extractSquareStickerFrames(
            videoFile = videoFile,
            durationMs = durationMs,
            maxFrames = 8,
            fallbackThumbnailFile = fallbackThumbnailFile
        )
        if (frames.isEmpty()) return false

        try {
            val safeTotalMs = durationMs.coerceIn(1_000L, 4_500L)
            val frameDurationMs = (safeTotalMs / frames.size).toInt().coerceIn(70, 500)

            val qualitySteps = intArrayOf(50, 32, 20)
            for (quality in qualitySteps) {
                val webpBytes = buildAnimatedWebpBytes(
                    bitmaps = frames,
                    frameDurationMs = frameDurationMs,
                    quality = quality
                )
                if (webpBytes.isNotEmpty() && webpBytes.size <= MAX_WHATSAPP_ANIMATED_BYTES) {
                    outputWebpFile.parentFile?.mkdirs()
                    FileOutputStream(outputWebpFile).use { it.write(webpBytes) }
                    return true
                }
            }

            // Fallback com 5 quadros caso o vídeo tenha alta complexidade visual
            val reducedFrames = frames.filterIndexed { index, _ -> index % 2 == 0 }.ifEmpty {
                listOf(frames.first())
            }
            val reducedDuration = (safeTotalMs / reducedFrames.size).toInt().coerceIn(100, 800)
            val fallbackBytes = buildAnimatedWebpBytes(
                bitmaps = reducedFrames,
                frameDurationMs = reducedDuration,
                quality = 24
            )
            if (fallbackBytes.isNotEmpty() && fallbackBytes.size <= MAX_WHATSAPP_ANIMATED_BYTES) {
                outputWebpFile.parentFile?.mkdirs()
                FileOutputStream(outputWebpFile).use { it.write(fallbackBytes) }
                return true
            }

            return false
        } finally {
            frames.forEach { runCatching { it.recycle() } }
        }
    }

    /**
     * Gera um sticker WebP animado válido (512x512) para completar o mínimo de 3 figurinhas
     * exigido pelo WhatsApp quando o usuário cria sua 1ª ou 2ª figurinha.
     */
    fun generateBrandedFillerWebp(outputWebpFile: File, variantIndex: Int): Boolean {
        val frame1 = createBadgeBitmap(STICKER_CANVAS_SIZE, pulseScale = 0.92f, variantIndex)
        val frame2 = createBadgeBitmap(STICKER_CANVAS_SIZE, pulseScale = 1.0f, variantIndex)
        return try {
            val bytes = buildAnimatedWebpBytes(
                bitmaps = listOf(frame1, frame2),
                frameDurationMs = 450,
                quality = 75
            )
            if (bytes.isEmpty()) return false
            outputWebpFile.parentFile?.mkdirs()
            FileOutputStream(outputWebpFile).use { it.write(bytes) }
            true
        } finally {
            frame1.recycle()
            frame2.recycle()
        }
    }

    /**
     * Gera o ícone oficial da bandeja do WhatsApp (PNG 96x96 px, < 50 KB).
     */
    fun generateTrayIconPng(outputPngFile: File): Boolean {
        val iconBitmap = createBadgeBitmap(TRAY_ICON_SIZE, pulseScale = 1.0f, variantIndex = 0)
        return try {
            outputPngFile.parentFile?.mkdirs()
            FileOutputStream(outputPngFile).use { out ->
                iconBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            outputPngFile.exists() && outputPngFile.length() > 0L
        } finally {
            iconBitmap.recycle()
        }
    }

    private fun extractSquareStickerFrames(
        videoFile: File,
        durationMs: Long,
        maxFrames: Int,
        fallbackThumbnailFile: File?
    ): List<Bitmap> {
        val result = mutableListOf<Bitmap>()
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(videoFile.absolutePath)
            val safeDurationMs = durationMs.coerceIn(300L, 6_000L)
            val targetCount = if (safeDurationMs < 1_000L) 5 else maxFrames
            val stepUs = (safeDurationMs * 1000L) / targetCount

            for (i in 0 until targetCount) {
                val timeUs = i * stepUs
                val rawFrame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    retriever.getScaledFrameAtTime(
                        timeUs,
                        MediaMetadataRetriever.OPTION_CLOSEST,
                        STICKER_CANVAS_SIZE,
                        STICKER_CANVAS_SIZE
                    )
                } else {
                    retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                }

                if (rawFrame != null) {
                    val squareCanvas = fitCenterTo512Square(rawFrame, 1.0f)
                    rawFrame.recycle()
                    result.add(squareCanvas)
                }
            }
        } catch (ignored: Exception) {
            // Usa fallback abaixo se necessário
        } finally {
            runCatching { retriever.release() }
        }

        // Garante que mesmo se o retriever falhar em um codec incomum, a imagem de capa vira sticker
        if (result.isEmpty() && fallbackThumbnailFile != null && fallbackThumbnailFile.exists()) {
            val decoded = BitmapFactory.decodeFile(fallbackThumbnailFile.absolutePath)
            if (decoded != null) {
                result.add(fitCenterTo512Square(decoded, 0.96f))
                result.add(fitCenterTo512Square(decoded, 1.0f))
                decoded.recycle()
            }
        }

        // WhatsApp exige pelo menos 2 quadros em figurinhas animadas
        if (result.size == 1) {
            result.add(result[0].copy(Bitmap.Config.ARGB_8888, false))
        }

        return result
    }

    private fun fitCenterTo512Square(source: Bitmap, zoomFactor: Float): Bitmap {
        val canvasBitmap = Bitmap.createBitmap(
            STICKER_CANVAS_SIZE,
            STICKER_CANVAS_SIZE,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(canvasBitmap)
        canvas.drawColor(Color.TRANSPARENT)

        val srcW = source.width.coerceAtLeast(1).toFloat()
        val srcH = source.height.coerceAtLeast(1).toFloat()
        val scale = minOf(STICKER_CANVAS_SIZE / srcW, STICKER_CANVAS_SIZE / srcH) * zoomFactor
        val dstW = srcW * scale
        val dstH = srcH * scale
        val left = (STICKER_CANVAS_SIZE - dstW) / 2f
        val top = (STICKER_CANVAS_SIZE - dstH) / 2f

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(source, null, RectF(left, top, left + dstW, top + dstH), paint)
        return canvasBitmap
    }

    private fun createBadgeBitmap(size: Int, pulseScale: Float, variantIndex: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.TRANSPARENT)

        val center = size / 2f
        val radius = (size * 0.42f) * pulseScale

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (variantIndex % 2 == 0) Color.parseColor("#25D366") else Color.parseColor("#128C7E")
            style = Paint.Style.FILL
        }
        canvas.drawCircle(center, center, radius, bgPaint)

        val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            strokeWidth = (size * 0.055f).coerceAtLeast(3f)
            strokeCap = Paint.Cap.ROUND
        }

        val offsets = floatArrayOf(-0.22f, -0.11f, 0f, 0.11f, 0.22f)
        val heights = floatArrayOf(0.14f, 0.28f, 0.36f, 0.24f, 0.14f)
        for (i in offsets.indices) {
            val x = center + size * offsets[i]
            val halfH = (size * heights[i] * 0.5f) * pulseScale
            canvas.drawLine(x, center - halfH, x, center + halfH, barPaint)
        }

        return bitmap
    }

    /**
     * Constrói o contêiner binário RIFF WEBP animado (VP8X + ANIM + ANMF) a partir de quadros WebP.
     */
    private fun buildAnimatedWebpBytes(
        bitmaps: List<Bitmap>,
        frameDurationMs: Int,
        quality: Int
    ): ByteArray {
        val frameChunksList = mutableListOf<ByteArray>()
        var anyAlpha = false

        for (bmp in bitmaps) {
            val singleWebp = compressBitmapToSingleWebp(bmp, quality) ?: return ByteArray(0)
            val extracted = extractBitstreamSubChunks(singleWebp) ?: return ByteArray(0)
            if (extracted.hasAlpha) anyAlpha = true
            frameChunksList.add(extracted.payloadBytes)
        }

        val bodyStream = ByteArrayOutputStream()
        bodyStream.write("WEBP".toByteArray(Charsets.US_ASCII))

        // 1. VP8X Header (10 bytes)
        val vp8xPayload = ByteArray(10)
        var vp8xFlags = 0x02 // Animation bit
        if (anyAlpha) vp8xFlags = vp8xFlags or 0x10 // Alpha bit
        vp8xPayload[0] = vp8xFlags.toByte()
        writeUInt24LE(vp8xPayload, 4, STICKER_CANVAS_SIZE - 1)
        writeUInt24LE(vp8xPayload, 7, STICKER_CANVAS_SIZE - 1)
        writeRiffChunk(bodyStream, "VP8X", vp8xPayload)

        // 2. ANIM Header (6 bytes: background color BGRA=0 transparente, loopCount=0 infinito)
        val animPayload = ByteArray(6)
        writeRiffChunk(bodyStream, "ANIM", animPayload)

        // 3. ANMF Chunks (1 por quadro, com dispose-to-background + no-blend = 0x03)
        for (subChunks in frameChunksList) {
            val anmfHeader = ByteArray(16)
            writeUInt24LE(anmfHeader, 0, 0)
            writeUInt24LE(anmfHeader, 3, 0)
            writeUInt24LE(anmfHeader, 6, STICKER_CANVAS_SIZE - 1)
            writeUInt24LE(anmfHeader, 9, STICKER_CANVAS_SIZE - 1)
            writeUInt24LE(anmfHeader, 12, frameDurationMs)
            anmfHeader[15] = 0x03 // Bit 0 = Dispose to background, Bit 1 = Do not blend

            val anmfPayload = ByteArrayOutputStream(16 + subChunks.size)
            anmfPayload.write(anmfHeader)
            anmfPayload.write(subChunks)
            writeRiffChunk(bodyStream, "ANMF", anmfPayload.toByteArray())
        }

        val webpBody = bodyStream.toByteArray()
        val riffOut = ByteArrayOutputStream(8 + webpBody.size)
        riffOut.write("RIFF".toByteArray(Charsets.US_ASCII))
        writeUInt32LE(riffOut, webpBody.size)
        riffOut.write(webpBody)
        return riffOut.toByteArray()
    }

    private fun compressBitmapToSingleWebp(bitmap: Bitmap, quality: Int): ByteArray? {
        val baos = ByteArrayOutputStream()
        val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Bitmap.CompressFormat.WEBP_LOSSY
        } else {
            @Suppress("DEPRECATION")
            Bitmap.CompressFormat.WEBP
        }
        val ok = bitmap.compress(format, quality, baos)
        return if (ok) baos.toByteArray() else null
    }

    private data class ExtractedFrameChunks(
        val payloadBytes: ByteArray,
        val hasAlpha: Boolean
    )

    private fun extractBitstreamSubChunks(singleWebp: ByteArray): ExtractedFrameChunks? {
        if (singleWebp.size < 20) return null
        val out = ByteArrayOutputStream()
        var hasAlpha = false
        var offset = 12

        while (offset + 8 <= singleWebp.size) {
            val fourCC = String(singleWebp, offset, 4, Charsets.US_ASCII)
            val chunkSize = readUInt32LE(singleWebp, offset + 4)
            if (chunkSize < 0 || offset + 8 + chunkSize > singleWebp.size) break

            val paddedSize = chunkSize + (chunkSize and 1)
            if (fourCC == "ALPH" || fourCC == "VP8 " || fourCC == "VP8L") {
                if (fourCC == "ALPH" || fourCC == "VP8L") hasAlpha = true
                out.write(singleWebp, offset, 8 + paddedSize.coerceAtMost(singleWebp.size - offset - 8))
            }
            offset += 8 + paddedSize
        }

        val bytes = out.toByteArray()
        return if (bytes.isNotEmpty()) ExtractedFrameChunks(bytes, hasAlpha) else null
    }

    private fun writeRiffChunk(out: ByteArrayOutputStream, fourCC: String, payload: ByteArray) {
        out.write(fourCC.toByteArray(Charsets.US_ASCII))
        writeUInt32LE(out, payload.size)
        out.write(payload)
        if (payload.size % 2 == 1) {
            out.write(0)
        }
    }

    private fun writeUInt24LE(buffer: ByteArray, offset: Int, value: Int) {
        buffer[offset] = (value and 0xFF).toByte()
        buffer[offset + 1] = ((value shr 8) and 0xFF).toByte()
        buffer[offset + 2] = ((value shr 16) and 0xFF).toByte()
    }

    private fun writeUInt32LE(out: ByteArrayOutputStream, value: Int) {
        out.write(value and 0xFF)
        out.write((value shr 8) and 0xFF)
        out.write((value shr 16) and 0xFF)
        out.write((value shr 24) and 0xFF)
    }

    private fun readUInt32LE(buffer: ByteArray, offset: Int): Int {
        return (buffer[offset].toInt() and 0xFF) or
            ((buffer[offset + 1].toInt() and 0xFF) shl 8) or
            ((buffer[offset + 2].toInt() and 0xFF) shl 16) or
            ((buffer[offset + 3].toInt() and 0xFF) shl 24)
    }
}
