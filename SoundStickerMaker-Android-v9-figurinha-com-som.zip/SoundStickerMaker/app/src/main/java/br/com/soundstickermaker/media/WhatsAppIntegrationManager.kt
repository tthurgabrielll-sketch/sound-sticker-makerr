package br.com.soundstickermaker.media

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.FileProvider
import br.com.soundstickermaker.data.preferences.WhatsAppTarget
import br.com.soundstickermaker.stickers.StickerContentProvider
import java.io.File

data class WhatsAppSupportStatus(
    val isStandardInstalled: Boolean,
    val isBusinessInstalled: Boolean,
    val hasNativeAudioStickerApi: Boolean,
    val technicalExplanation: String
) {
    val isAnyWhatsAppInstalled: Boolean
        get() = isStandardInstalled || isBusinessInstalled
}

sealed interface ShareDispatchResult {
    data object Dispatched : ShareDispatchResult
    data class Error(val userMessage: String) : ShareDispatchResult
}

object WhatsAppIntegrationManager {

    const val PKG_WHATSAPP_STANDARD = "com.whatsapp"
    const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"

    const val ERROR_WHATSAPP_NOT_INSTALLED =
        "O WhatsApp não está instalado neste dispositivo. Instale o WhatsApp ou use o botão COMPARTILHAR."
    const val ERROR_SHARE_FAILED =
        "Não foi possível concluir a ação no WhatsApp. Tente novamente."
    const val ERROR_OPEN_FAILED =
        "Não foi possível abrir o WhatsApp. Abra-o manualmente."
    const val INFO_NATIVE_FORMAT_LIMITATION =
        "Por que a figurinha com som não vai direto para a bandeja? O WhatsApp só aceita som em " +
            "figurinhas criadas no editor dele (liberação gradual desde 24/11): o formato WebP " +
            "não guarda áudio e a API pública de pacotes não tem campo de som. Por isso o app " +
            "deixa o clipe de 5 s e o áudio prontos na galeria e você só escolhe os arquivos no " +
            "editor. ADICIONAR À BANDEJA importa a figurinha animada, mas sem som."

    fun inspectWhatsAppSupport(context: Context): WhatsAppSupportStatus {
        val pm = context.packageManager
        val standardInstalled = isPackageInstalled(pm, PKG_WHATSAPP_STANDARD)
        val businessInstalled = isPackageInstalled(pm, PKG_WHATSAPP_BUSINESS)

        val stickerPackProbe = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK")
        val resolvedReceivers = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                stickerPackProbe,
                PackageManager.ResolveInfoFlags.of(0L)
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(stickerPackProbe, 0)
        }
        val nativeStickerApiAvailable = resolvedReceivers.isNotEmpty()

        val explanation = if (nativeStickerApiAvailable) {
            "Protocolo oficial de pacotes de figurinhas do WhatsApp ativo (StickerContentProvider 512x512 WebP animado)."
        } else {
            "Instale ou atualize o WhatsApp para importar pacotes diretamente na aba de figurinhas."
        }

        return WhatsAppSupportStatus(
            isStandardInstalled = standardInstalled,
            isBusinessInstalled = businessInstalled,
            hasNativeAudioStickerApi = nativeStickerApiAvailable,
            technicalExplanation = explanation
        )
    }

    /**
     * Abre o diálogo nativo do WhatsApp ("Deseja adicionar Sound Sticker Maker ao WhatsApp?")
     * adicionando a figurinha à bandeja oficial do WhatsApp.
     *
     * ATENÇÃO: a API pública de pacotes de terceiros (WebP animado) não tem campo de áudio,
     * então a figurinha importada por aqui fica SEM som. Figurinhas com som (recurso que o
     * WhatsApp começou a liberar em nov/2026) são criadas no editor do próprio WhatsApp.
     */
    fun addStickerPackToWhatsApp(
        context: Context,
        preferredTarget: WhatsAppTarget
    ): ShareDispatchResult {
        val status = inspectWhatsAppSupport(context)
        if (!status.isAnyWhatsAppInstalled) {
            return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)
        }

        val targetPackage = resolveTargetPackage(status, preferredTarget)
            ?: return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)

        return try {
            val intent = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK").apply {
                putExtra("sticker_pack_id", StickerContentProvider.PACK_IDENTIFIER)
                putExtra(
                    "sticker_pack_authority",
                    "${context.packageName}.stickercontentprovider"
                )
                putExtra("sticker_pack_name", StickerContentProvider.PACK_NAME)
                setPackage(targetPackage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ShareDispatchResult.Dispatched
        } catch (ignored: Exception) {
            ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }
    }

    /** Abre o WhatsApp (ou o WhatsApp Business) na tela inicial, sem anexar nada. */
    fun openWhatsApp(
        context: Context,
        preferredTarget: WhatsAppTarget
    ): ShareDispatchResult {
        val status = inspectWhatsAppSupport(context)
        if (!status.isAnyWhatsAppInstalled) {
            return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)
        }

        val targetPackage = resolveTargetPackage(status, preferredTarget)
            ?: return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)

        val launchIntent = context.packageManager.getLaunchIntentForPackage(targetPackage)
            ?: return ShareDispatchResult.Error(ERROR_OPEN_FAILED)

        return try {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            ShareDispatchResult.Dispatched
        } catch (ignored: Exception) {
            ShareDispatchResult.Error(ERROR_OPEN_FAILED)
        }
    }

    fun shareViaSystemChooser(
        context: Context,
        videoFile: File
    ): ShareDispatchResult {
        if (!videoFile.exists() || videoFile.length() == 0L) {
            return ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }

        return try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                videoFile
            )

            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                clipData = ClipData.newRawUri("Sound Sticker", contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(
                sendIntent,
                "Compartilhar figurinha com som"
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(chooser)
            ShareDispatchResult.Dispatched
        } catch (ignored: Exception) {
            ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }
    }

    private fun resolveTargetPackage(
        status: WhatsAppSupportStatus,
        preferredTarget: WhatsAppTarget
    ): String? {
        return when (preferredTarget) {
            WhatsAppTarget.STANDARD -> {
                if (status.isStandardInstalled) PKG_WHATSAPP_STANDARD
                else if (status.isBusinessInstalled) PKG_WHATSAPP_BUSINESS
                else null
            }
            WhatsAppTarget.BUSINESS -> {
                if (status.isBusinessInstalled) PKG_WHATSAPP_BUSINESS
                else if (status.isStandardInstalled) PKG_WHATSAPP_STANDARD
                else null
            }
            WhatsAppTarget.AUTO -> {
                if (status.isStandardInstalled) PKG_WHATSAPP_STANDARD
                else if (status.isBusinessInstalled) PKG_WHATSAPP_BUSINESS
                else null
            }
        }
    }

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, 0)
            }
            true
        } catch (ignored: PackageManager.NameNotFoundException) {
            false
        }
    }
}
