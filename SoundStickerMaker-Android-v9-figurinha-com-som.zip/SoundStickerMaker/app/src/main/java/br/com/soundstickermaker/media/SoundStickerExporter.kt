package br.com.soundstickermaker.media

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * O que ficou pronto na galeria do celular para o editor de figurinhas com som do WhatsApp.
 *
 * [audioDisplayName] é nulo quando o vídeo original não tem trilha de áudio.
 */
data class SoundStickerExportResult(
    val clipDisplayName: String,
    val audioDisplayName: String?,
    val clipDurationMs: Long
)

/**
 * Prepara os dois arquivos que o editor de figurinhas do WhatsApp aceita para montar uma
 * figurinha COM SOM (o formato WebP das figurinhas não guarda áudio e a API pública de pacotes
 * não tem campo de som, então o app não consegue "injetar" o áudio direto na bandeja):
 *
 *  1. Um clipe MP4 de até 5 s, com o áudio original. É o limite de áudio que o WhatsApp mantém
 *     quando a figurinha animada nasce de um vídeo.
 *  2. Um áudio M4A (AAC) de até 10 s, para escolher no ícone de onda sonora do editor caso o
 *     WhatsApp não traga o som do vídeo sozinho.
 *
 * Os dois são copiados SEM recodificar (só empacotamento), por isso o processo é instantâneo e
 * não perde qualidade. Ficam em Filmes/SoundStickerMaker e Música/SoundStickerMaker.
 */
object SoundStickerExporter {

    const val CLIP_MAX_DURATION_MS = 5_000L
    const val AUDIO_MAX_DURATION_MS = 10_000L
    const val MEDIA_FOLDER = "SoundStickerMaker"

    const val ERROR_EXPORT_FAILED =
        "Não consegui preparar o clipe e o áudio para o WhatsApp. Tente novamente."
    const val ERROR_NEEDS_ANDROID_10 =
        "Para deixar o clipe e o áudio na galeria é preciso Android 10 ou mais novo."

    private val VALID_ROTATIONS = intArrayOf(0, 90, 180, 270)

    suspend fun export(
        context: Context,
        sourceVideo: File,
        stickerKey: Long
    ): Result<SoundStickerExportResult> = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return@withContext Result.failure<SoundStickerExportResult>(
                IllegalStateException(ERROR_NEEDS_ANDROID_10)
            )
        }
        if (!sourceVideo.exists() || sourceVideo.length() == 0L) {
            return@withContext Result.failure<SoundStickerExportResult>(
                IllegalStateException(ERROR_EXPORT_FAILED)
            )
        }

        val tempDir = File(context.cacheDir, "processed").apply {
            if (!exists()) mkdirs()
        }
        val clipTemp = File(tempDir, "sound_clip_$stickerKey.mp4")
        val audioTemp = File(tempDir, "sound_audio_$stickerKey.m4a")

        try {
            val info = inspectSource(sourceVideo)

            val clipName = "figurinha_com_som_$stickerKey.mp4"
            val clipReady = remux(
                source = sourceVideo,
                output = clipTemp,
                maxDurationMs = CLIP_MAX_DURATION_MS,
                includeVideo = true,
                rotationDegrees = info.rotationDegrees
            ) && publishToMediaStore(
                context = context,
                source = clipTemp,
                displayName = clipName,
                mimeType = "video/mp4",
                collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),
                relativePath = "${Environment.DIRECTORY_MOVIES}/$MEDIA_FOLDER"
            )

            if (!clipReady) {
                return@withContext Result.failure<SoundStickerExportResult>(
                    IllegalStateException(ERROR_EXPORT_FAILED)
                )
            }

            var audioName: String? = null
            if (info.hasAudio) {
                val candidate = "audio_figurinha_$stickerKey.m4a"
                val audioReady = remux(
                    source = sourceVideo,
                    output = audioTemp,
                    maxDurationMs = AUDIO_MAX_DURATION_MS,
                    includeVideo = false,
                    rotationDegrees = 0
                ) && publishToMediaStore(
                    context = context,
                    source = audioTemp,
                    displayName = candidate,
                    mimeType = "audio/mp4",
                    collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),
                    relativePath = "${Environment.DIRECTORY_MUSIC}/$MEDIA_FOLDER"
                )
                if (audioReady) audioName = candidate
            }

            val clipDurationMs = if (info.durationMs > 0L) {
                minOf(info.durationMs, CLIP_MAX_DURATION_MS)
            } else {
                CLIP_MAX_DURATION_MS
            }

            Result.success(
                SoundStickerExportResult(
                    clipDisplayName = clipName,
                    audioDisplayName = audioName,
                    clipDurationMs = clipDurationMs
                )
            )
        } catch (e: Exception) {
            Result.failure<SoundStickerExportResult>(
                IllegalStateException(ERROR_EXPORT_FAILED, e)
            )
        } finally {
            runCatching { clipTemp.delete() }
            runCatching { audioTemp.delete() }
        }
    }

    private data class SourceInfo(
        val hasAudio: Boolean,
        val durationMs: Long,
        val rotationDegrees: Int
    )

    private fun inspectSource(file: File): SourceInfo {
        var hasAudio = false
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(file.absolutePath)
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) hasAudio = true
            }
        } finally {
            runCatching { extractor.release() }
        }

        var durationMs = 0L
        var rotation = 0
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(file.absolutePath)
            durationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            rotation = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull() ?: 0
        } catch (ignored: Exception) {
            // Sem duração/rotação o export continua com os valores padrão.
        } finally {
            runCatching { retriever.release() }
        }

        return SourceInfo(hasAudio, durationMs, rotation)
    }

    /**
     * Copia os pacotes comprimidos do início do arquivo (sem decodificar nem recodificar).
     * [includeVideo] = true gera um MP4 com vídeo e, se existir, o áudio; false gera só o áudio.
     */
    private fun remux(
        source: File,
        output: File,
        maxDurationMs: Long,
        includeVideo: Boolean,
        rotationDegrees: Int
    ): Boolean {
        if (output.exists()) output.delete()

        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(source.absolutePath)

            var videoTrack = -1
            var audioTrack = -1
            var bufferSize = 1024 * 1024
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                val wanted = when {
                    mime.startsWith("video/") && includeVideo && videoTrack == -1 -> {
                        videoTrack = i
                        true
                    }
                    mime.startsWith("audio/") && audioTrack == -1 -> {
                        audioTrack = i
                        true
                    }
                    else -> false
                }
                if (wanted && format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                    bufferSize = maxOf(bufferSize, format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
                }
            }

            if (includeVideo && videoTrack == -1) return false
            if (!includeVideo && audioTrack == -1) return false

            val localMuxer = MediaMuxer(
                output.absolutePath,
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            )
            muxer = localMuxer

            if (videoTrack != -1 && rotationDegrees in VALID_ROTATIONS) {
                localMuxer.setOrientationHint(rotationDegrees)
            }
            val muxerVideoTrack = if (videoTrack != -1) {
                localMuxer.addTrack(extractor.getTrackFormat(videoTrack))
            } else {
                -1
            }
            val muxerAudioTrack = if (audioTrack != -1) {
                localMuxer.addTrack(extractor.getTrackFormat(audioTrack))
            } else {
                -1
            }
            localMuxer.start()

            val maxDurationUs = maxDurationMs * 1000L
            val buffer = ByteBuffer.allocateDirect(bufferSize)
            val bufferInfo = MediaCodec.BufferInfo()

            var lastVideoPtsUs = 0L
            if (videoTrack != -1) {
                lastVideoPtsUs = copyTrack(
                    extractor, videoTrack, localMuxer, muxerVideoTrack,
                    buffer, bufferInfo, maxDurationUs
                )
            }
            if (audioTrack != -1) {
                // No clipe, o áudio acompanha exatamente o último quadro de vídeo gravado.
                val audioLimitUs = if (videoTrack != -1 && lastVideoPtsUs > 0L) {
                    lastVideoPtsUs
                } else {
                    maxDurationUs
                }
                copyTrack(
                    extractor, audioTrack, localMuxer, muxerAudioTrack,
                    buffer, bufferInfo, audioLimitUs
                )
            }

            localMuxer.stop()
            localMuxer.release()
            muxer = null

            return output.exists() && output.length() > 0L
        } catch (ignored: Exception) {
            runCatching { muxer?.release() }
            runCatching { output.delete() }
            return false
        } finally {
            runCatching { extractor.release() }
        }
    }

    /** Devolve o maior timestamp (µs) gravado, já normalizado para começar em zero. */
    private fun copyTrack(
        extractor: MediaExtractor,
        sourceTrack: Int,
        muxer: MediaMuxer,
        muxerTrack: Int,
        buffer: ByteBuffer,
        bufferInfo: MediaCodec.BufferInfo,
        limitUs: Long
    ): Long {
        extractor.selectTrack(sourceTrack)
        extractor.seekTo(0L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

        var basePtsUs = -1L
        var maxWrittenPtsUs = 0L

        while (true) {
            buffer.clear()
            val sampleSize = extractor.readSampleData(buffer, 0)
            if (sampleSize < 0) break

            val rawPtsUs = extractor.sampleTime
            if (rawPtsUs < 0L) {
                extractor.advance()
                continue
            }
            if (basePtsUs < 0L) basePtsUs = rawPtsUs
            val ptsUs = (rawPtsUs - basePtsUs).coerceAtLeast(0L)
            if (ptsUs > limitUs) break

            bufferInfo.offset = 0
            bufferInfo.size = sampleSize
            bufferInfo.presentationTimeUs = ptsUs
            bufferInfo.flags = extractor.sampleFlags and MediaCodec.BUFFER_FLAG_END_OF_STREAM.inv()
            muxer.writeSampleData(muxerTrack, buffer, bufferInfo)

            if (ptsUs > maxWrittenPtsUs) maxWrittenPtsUs = ptsUs
            extractor.advance()
        }

        extractor.unselectTrack(sourceTrack)
        return maxWrittenPtsUs
    }

    private fun publishToMediaStore(
        context: Context,
        source: File,
        displayName: String,
        mimeType: String,
        collection: Uri,
        relativePath: String
    ): Boolean {
        if (!source.exists() || source.length() == 0L) return false

        val resolver = context.contentResolver
        // Mesma figurinha, mesmo nome: reaproveita o arquivo que já está na galeria.
        if (existsInMediaStore(resolver, collection, displayName)) return true

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val itemUri = resolver.insert(collection, values) ?: return false
        return try {
            val output = resolver.openOutputStream(itemUri)
                ?: throw IllegalStateException("Sem acesso de escrita ao arquivo na galeria")
            output.use { stream ->
                source.inputStream().use { input -> input.copyTo(stream) }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(itemUri, values, null, null)
            true
        } catch (ignored: Exception) {
            runCatching { resolver.delete(itemUri, null, null) }
            false
        }
    }

    private fun existsInMediaStore(
        resolver: ContentResolver,
        collection: Uri,
        displayName: String
    ): Boolean {
        return runCatching {
            resolver.query(
                collection,
                arrayOf(MediaStore.MediaColumns._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME} = ?",
                arrayOf(displayName),
                null
            )?.use { cursor -> cursor.moveToFirst() } ?: false
        }.getOrDefault(false)
    }
}
