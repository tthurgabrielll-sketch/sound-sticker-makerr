package br.com.soundstickermaker.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import kotlin.coroutines.resume

data class ProcessedMediaOutput(
    val outputVideoFile: File,
    val thumbnailFile: File?,
    val durationMs: Long,
    val wasAutoTrimmed: Boolean,
    val originalDurationMs: Long,
    val width: Int,
    val height: Int,
    val hasAudio: Boolean,
    val audioCodec: String,
    val videoCodec: String,
    val audioVideoSyncDeltaMs: Long
)

class MediaProcessor(private val context: Context) {

    companion object {
        const val ERROR_PROCESSING_FAILED =
            "Ocorreu uma falha ao processar o vídeo localmente. Tente novamente com outro arquivo."
    }

    suspend fun processVideoPreservingAudio(
        metadata: VideoMetadataInfo,
        preserveOriginalResolution: Boolean,
        onProgressChanged: (Float) -> Unit
    ): Result<ProcessedMediaOutput> {
        val outputDir = File(context.cacheDir, "processed").apply {
            if (!exists()) mkdirs()
        }
        val outputFile = File(outputDir, "temp_sticker_${System.currentTimeMillis()}.mp4")
        if (outputFile.exists()) outputFile.delete()

        val isAlreadyStandardCodecs =
            metadata.videoMimeType.equals("video/avc", ignoreCase = true) &&
                (!metadata.hasAudioTrack ||
                    metadata.audioMimeType.equals("audio/mp4a-latm", ignoreCase = true))

        val canUseZeroCopyFastPath =
            isAlreadyStandardCodecs &&
                (preserveOriginalResolution || maxOf(metadata.width, metadata.height) <= 720)

        // 1. Caminho ultra-rápido (< 150ms): cópia direta ou remuxing sem re-codificação
        if (canUseZeroCopyFastPath) {
            onProgressChanged(0.35f)
            val fastSuccess = if (!metadata.wasAutoTrimmed) {
                fastCopyDirectStream(metadata, outputFile)
            } else {
                fastTrimWithMediaMuxer(metadata, outputFile, VideoValidator.MAX_DURATION_MS)
            }

            if (fastSuccess) {
                onProgressChanged(0.9f)
                val verified = verifyOutputIntegrity(
                    outputFile = outputFile,
                    fallbackThumbnail = metadata.previewThumbnailFile,
                    expectedHasAudio = metadata.hasAudioTrack,
                    wasAutoTrimmed = metadata.wasAutoTrimmed,
                    originalDurationMs = metadata.originalDurationMs
                )
                if (verified.isSuccess) {
                    onProgressChanged(1.0f)
                    return verified
                }
            }
            runCatching { outputFile.delete() }
        }

        // 2. Fallback completo via Media3 Transformer com corte imediato em 20s se necessário
        return transcodeWithMedia3Transformer(
            metadata = metadata,
            outputFile = outputFile,
            preserveOriginalResolution = preserveOriginalResolution,
            onProgressChanged = onProgressChanged
        )
    }

    private suspend fun fastCopyDirectStream(
        metadata: VideoMetadataInfo,
        outputFile: File
    ): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openInputStream(metadata.sourceUri)?.use { input ->
                FileOutputStream(outputFile).use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                }
            } ?: return@runCatching false
            outputFile.exists() && outputFile.length() > 0L
        }.getOrDefault(false)
    }

    private suspend fun fastTrimWithMediaMuxer(
        metadata: VideoMetadataInfo,
        outputFile: File,
        maxDurationMs: Long
    ): Boolean = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(context, metadata.sourceUri, null)
            val trackCount = extractor.trackCount
            var sourceVideoTrack = -1
            var sourceAudioTrack = -1
            var videoMaxInputSize = 1024 * 1024
            var audioMaxInputSize = 256 * 1024

            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("video/") && sourceVideoTrack == -1) {
                    sourceVideoTrack = i
                    if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        videoMaxInputSize = maxOf(
                            videoMaxInputSize,
                            format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                        )
                    }
                } else if (mime.startsWith("audio/") && sourceAudioTrack == -1) {
                    sourceAudioTrack = i
                    if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        audioMaxInputSize = maxOf(
                            audioMaxInputSize,
                            format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                        )
                    }
                }
            }

            if (sourceVideoTrack == -1) return@withContext false

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val retriever = MediaMetadataRetriever()
            val rotation = runCatching {
                retriever.setDataSource(context, metadata.sourceUri)
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                    ?.toIntOrNull() ?: 0
            }.getOrDefault(0).also { runCatching { retriever.release() } }

            if (rotation in setOf(0, 90, 180, 270)) {
                muxer.setOrientationHint(rotation)
            }

            val muxerVideoTrack = muxer.addTrack(extractor.getTrackFormat(sourceVideoTrack))
            val muxerAudioTrack = if (sourceAudioTrack != -1) {
                muxer.addTrack(extractor.getTrackFormat(sourceAudioTrack))
            } else {
                -1
            }

            muxer.start()

            val maxDurationUs = maxDurationMs * 1000L
            val buffer = ByteBuffer.allocate(maxOf(videoMaxInputSize, audioMaxInputSize))
            val bufferInfo = MediaCodec.BufferInfo()

            // Copiar pacotes de vídeo até 20 segundos
            extractor.selectTrack(sourceVideoTrack)
            extractor.seekTo(0L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            var actualVideoEndUs = 0L
            while (true) {
                buffer.clear()
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs > maxDurationUs) break

                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = sampleTimeUs
                bufferInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(muxerVideoTrack, buffer, bufferInfo)
                actualVideoEndUs = sampleTimeUs
                extractor.advance()
            }
            extractor.unselectTrack(sourceVideoTrack)

            // Copiar pacotes de áudio sincronizados até a mesma marca final do vídeo
            if (sourceAudioTrack != -1 && muxerAudioTrack != -1) {
                val audioLimitUs = if (actualVideoEndUs > 0L) actualVideoEndUs else maxDurationUs
                extractor.selectTrack(sourceAudioTrack)
                extractor.seekTo(0L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                while (true) {
                    buffer.clear()
                    val sampleSize = extractor.readSampleData(buffer, 0)
                    if (sampleSize < 0) break
                    val sampleTimeUs = extractor.sampleTime
                    if (sampleTimeUs > audioLimitUs) break

                    bufferInfo.offset = 0
                    bufferInfo.size = sampleSize
                    bufferInfo.presentationTimeUs = sampleTimeUs
                    bufferInfo.flags = extractor.sampleFlags
                    muxer.writeSampleData(muxerAudioTrack, buffer, bufferInfo)
                    extractor.advance()
                }
                extractor.unselectTrack(sourceAudioTrack)
            }

            muxer.stop()
            muxer.release()
            muxer = null

            outputFile.exists() && outputFile.length() > 0L
        } catch (_: Exception) {
            runCatching { muxer?.release() }
            runCatching { outputFile.delete() }
            false
        } finally {
            runCatching { extractor.release() }
        }
    }

    @OptIn(UnstableApi::class)
    private suspend fun transcodeWithMedia3Transformer(
        metadata: VideoMetadataInfo,
        outputFile: File,
        preserveOriginalResolution: Boolean,
        onProgressChanged: (Float) -> Unit
    ): Result<ProcessedMediaOutput> = withContext(Dispatchers.Main) {
        val mediaItemBuilder = MediaItem.Builder().setUri(metadata.sourceUri)

        // Corte imediato nos primeiros 20 segundos caso o vídeo ultrapasse 20s
        if (metadata.wasAutoTrimmed) {
            mediaItemBuilder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(0L)
                    .setEndPositionMs(VideoValidator.MAX_DURATION_MS)
                    .build()
            )
        }

        val mediaItem = mediaItemBuilder.build()

        val videoEffects = if (!preserveOriginalResolution &&
            maxOf(metadata.width, metadata.height) > 720
        ) {
            listOf(Presentation.createForHeight(720))
        } else {
            emptyList()
        }

        val editedMediaItem = EditedMediaItem.Builder(mediaItem)
            .setRemoveAudio(false)
            .setRemoveVideo(false)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        suspendCancellableCoroutine { continuation ->
            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setLooper(Looper.getMainLooper())
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(
                        composition: Composition,
                        exportResult: ExportResult
                    ) {
                        if (!continuation.isActive) return
                        onProgressChanged(1.0f)

                        val verification = verifyOutputIntegrity(
                            outputFile = outputFile,
                            fallbackThumbnail = metadata.previewThumbnailFile,
                            expectedHasAudio = metadata.hasAudioTrack,
                            wasAutoTrimmed = metadata.wasAutoTrimmed,
                            originalDurationMs = metadata.originalDurationMs
                        )
                        continuation.resume(verification)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        if (!continuation.isActive) return
                        runCatching { outputFile.delete() }
                        continuation.resume(
                            Result.failure(
                                IllegalStateException(
                                    ERROR_PROCESSING_FAILED,
                                    exportException
                                )
                            )
                        )
                    }
                })
                .build()

            val progressHolder = ProgressHolder()
            val progressJob = launch {
                while (isActive) {
                    val state = transformer.getProgress(progressHolder)
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                        onProgressChanged((progressHolder.progress / 100f).coerceIn(0.05f, 0.95f))
                    }
                    delay(100L)
                }
            }

            continuation.invokeOnCancellation {
                progressJob.cancel()
                Handler(Looper.getMainLooper()).post {
                    runCatching { transformer.cancel() }
                    runCatching { outputFile.delete() }
                }
            }

            try {
                transformer.start(editedMediaItem, outputFile.absolutePath)
            } catch (e: Exception) {
                progressJob.cancel()
                if (continuation.isActive) {
                    continuation.resume(
                        Result.failure(IllegalStateException(ERROR_PROCESSING_FAILED, e))
                    )
                }
            }
        }
    }

    private fun verifyOutputIntegrity(
        outputFile: File,
        fallbackThumbnail: File?,
        expectedHasAudio: Boolean,
        wasAutoTrimmed: Boolean,
        originalDurationMs: Long
    ): Result<ProcessedMediaOutput> {
        if (!outputFile.exists() || outputFile.length() == 0L) {
            return Result.failure(IllegalStateException(ERROR_PROCESSING_FAILED))
        }

        val extractor = MediaExtractor()
        var videoDurationMs = 0L
        var audioDurationMs = 0L
        var hasAudio = false
        val videoCodec = "H.264 / AVC"
        var audioCodec = "Sem áudio original"

        try {
            extractor.setDataSource(outputFile.absolutePath)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                val durMs = if (format.containsKey(MediaFormat.KEY_DURATION)) {
                    format.getLong(MediaFormat.KEY_DURATION) / 1000L
                } else {
                    0L
                }

                if (mime.startsWith("video/")) {
                    videoDurationMs = durMs
                } else if (mime.startsWith("audio/")) {
                    hasAudio = true
                    audioDurationMs = durMs
                    audioCodec = "AAC-LC"
                }
            }
        } catch (e: Exception) {
            return Result.failure(IllegalStateException(ERROR_PROCESSING_FAILED, e))
        } finally {
            runCatching { extractor.release() }
        }

        if (expectedHasAudio && !hasAudio) {
            return Result.failure(IllegalStateException(ERROR_PROCESSING_FAILED))
        }

        val syncDelta = if (hasAudio && videoDurationMs > 0L && audioDurationMs > 0L) {
            kotlin.math.abs(videoDurationMs - audioDurationMs)
        } else {
            0L
        }

        val retriever = MediaMetadataRetriever()
        val finalDurationMs: Long
        val width: Int
        val height: Int
        var resolvedThumb: File? = fallbackThumbnail?.takeIf { it.exists() }
        try {
            retriever.setDataSource(outputFile.absolutePath)
            finalDurationMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: videoDurationMs
            val rawW = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
            )?.toIntOrNull() ?: 512
            val rawH = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
            )?.toIntOrNull() ?: 512
            val rotation = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
            )?.toIntOrNull() ?: 0

            if (rotation == 90 || rotation == 270) {
                width = rawH
                height = rawW
            } else {
                width = rawW
                height = rawH
            }

            if (resolvedThumb == null) {
                resolvedThumb = extractFallbackJpeg(retriever)
            }
        } finally {
            runCatching { retriever.release() }
        }

        return Result.success(
            ProcessedMediaOutput(
                outputVideoFile = outputFile,
                thumbnailFile = resolvedThumb,
                durationMs = finalDurationMs,
                wasAutoTrimmed = wasAutoTrimmed,
                originalDurationMs = originalDurationMs,
                width = width,
                height = height,
                hasAudio = hasAudio,
                audioCodec = audioCodec,
                videoCodec = videoCodec,
                audioVideoSyncDeltaMs = syncDelta
            )
        )
    }

    private fun extractFallbackJpeg(retriever: MediaMetadataRetriever): File? {
        return runCatching {
            val bitmap = retriever.getFrameAtTime(
                0L,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            ) ?: return null
            val cacheDir = File(context.cacheDir, "processed").apply {
                if (!exists()) mkdirs()
            }
            val thumbFile = File(cacheDir, "fallback_thumb_${System.currentTimeMillis()}.jpg")
            FileOutputStream(thumbFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
            }
            bitmap.recycle()
            thumbFile
        }.getOrNull()
    }
}
