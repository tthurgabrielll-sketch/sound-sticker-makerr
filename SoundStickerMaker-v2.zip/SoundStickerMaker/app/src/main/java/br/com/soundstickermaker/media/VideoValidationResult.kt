package br.com.soundstickermaker.media

import android.net.Uri
import java.io.File

data class VideoMetadataInfo(
    val sourceUri: Uri,
    val originalDurationMs: Long,
    val targetDurationMs: Long,
    val wasAutoTrimmed: Boolean,
    val width: Int,
    val height: Int,
    val hasVideoTrack: Boolean,
    val hasAudioTrack: Boolean,
    val videoMimeType: String,
    val audioMimeType: String,
    val fileSizeBytes: Long,
    val previewThumbnailFile: File?
)

sealed interface VideoValidationResult {
    data class Valid(val metadata: VideoMetadataInfo) : VideoValidationResult
    data class Invalid(val userMessage: String) : VideoValidationResult
}
