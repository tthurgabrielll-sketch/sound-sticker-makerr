package br.com.soundstickermaker.ui.model

import br.com.soundstickermaker.data.local.StickerEntity
import br.com.soundstickermaker.data.preferences.UserSettings
import br.com.soundstickermaker.media.ProcessedMediaOutput
import br.com.soundstickermaker.media.WhatsAppSupportStatus
import java.io.File

sealed interface AppScreenRoute {
    data object Home : AppScreenRoute
    data object Processing : AppScreenRoute
    data object Preview : AppScreenRoute
    data object Library : AppScreenRoute
    data object Settings : AppScreenRoute
}

data class ActivePreviewItem(
    val videoFile: File,
    val thumbnailFile: File?,
    val durationMs: Long,
    val wasAutoTrimmed: Boolean = false,
    val originalDurationMs: Long = durationMs,
    val width: Int,
    val height: Int,
    val hasAudio: Boolean,
    val audioCodec: String,
    val videoCodec: String,
    val isAlreadySavedInLibrary: Boolean,
    val savedEntityId: Long? = null
) {
    companion object {
        fun fromProcessed(output: ProcessedMediaOutput): ActivePreviewItem {
            return ActivePreviewItem(
                videoFile = output.outputVideoFile,
                thumbnailFile = output.thumbnailFile,
                durationMs = output.durationMs,
                wasAutoTrimmed = output.wasAutoTrimmed,
                originalDurationMs = output.originalDurationMs,
                width = output.width,
                height = output.height,
                hasAudio = output.hasAudio,
                audioCodec = output.audioCodec,
                videoCodec = output.videoCodec,
                isAlreadySavedInLibrary = false
            )
        }

        fun fromEntity(entity: StickerEntity): ActivePreviewItem {
            return ActivePreviewItem(
                videoFile = File(entity.videoFilePath),
                thumbnailFile = File(entity.thumbnailFilePath),
                durationMs = entity.durationMs,
                wasAutoTrimmed = false,
                originalDurationMs = entity.durationMs,
                width = entity.width,
                height = entity.height,
                hasAudio = entity.hasAudio,
                audioCodec = entity.audioCodec,
                videoCodec = entity.videoCodec,
                isAlreadySavedInLibrary = true,
                savedEntityId = entity.id
            )
        }
    }
}

data class SoundStickerUiState(
    val currentScreen: AppScreenRoute = AppScreenRoute.Home,
    val processingThumbnail: File? = null,
    val processingProgress: Float = 0f,
    val isAutoTrimmingLongVideo: Boolean = false,
    val activePreview: ActivePreviewItem? = null,
    val recentStickers: List<StickerEntity> = emptyList(),
    val allStickers: List<StickerEntity> = emptyList(),
    val settings: UserSettings = UserSettings(),
    val whatsAppSupport: WhatsAppSupportStatus? = null,
    val errorMessage: String? = null,
    val infoBannerMessage: String? = null
)
