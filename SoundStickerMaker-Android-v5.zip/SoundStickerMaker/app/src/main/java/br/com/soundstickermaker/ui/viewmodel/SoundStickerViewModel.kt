package br.com.soundstickermaker.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import br.com.soundstickermaker.SoundStickerApp
import br.com.soundstickermaker.data.local.StickerEntity
import br.com.soundstickermaker.data.preferences.WhatsAppTarget
import br.com.soundstickermaker.media.MediaProcessor
import br.com.soundstickermaker.media.ShareDispatchResult
import br.com.soundstickermaker.media.VideoValidationResult
import br.com.soundstickermaker.media.VideoValidator
import br.com.soundstickermaker.media.WhatsAppIntegrationManager
import br.com.soundstickermaker.ui.model.ActivePreviewItem
import br.com.soundstickermaker.ui.model.AppScreenRoute
import br.com.soundstickermaker.ui.model.SoundStickerUiState
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

class SoundStickerViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as SoundStickerApp
    private val repository = app.stickerRepository
    private val preferences = app.preferencesRepository
    private val mediaProcessor = MediaProcessor(application)

    private val _uiState = MutableStateFlow(
        SoundStickerUiState(
            whatsAppSupport = WhatsAppIntegrationManager.inspectWhatsAppSupport(application)
        )
    )
    val uiState: StateFlow<SoundStickerUiState> = _uiState.asStateFlow()

    private var activeProcessingJob: Job? = null

    init {
        viewModelScope.launch {
            repository.observeRecentStickers(limit = 6).collect { recents ->
                _uiState.update { it.copy(recentStickers = recents) }
            }
        }
        viewModelScope.launch {
            repository.observeAllStickers().collect { all ->
                _uiState.update { it.copy(allStickers = all) }
            }
        }
        viewModelScope.launch {
            preferences.settingsFlow.collect { settings ->
                _uiState.update { it.copy(settings = settings) }
            }
        }
    }

    fun onVideoSelectedFromGallery(uri: Uri) {
        activeProcessingJob?.cancel()
        activeProcessingJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    currentScreen = AppScreenRoute.Processing,
                    processingThumbnail = null,
                    processingProgress = 0.1f,
                    isAutoTrimmingLongVideo = false,
                    errorMessage = null,
                    infoBannerMessage = null
                )
            }

            when (val validation = VideoValidator.validateVideoUri(app, uri)) {
                is VideoValidationResult.Invalid -> {
                    _uiState.update {
                        it.copy(
                            currentScreen = AppScreenRoute.Home,
                            processingThumbnail = null,
                            errorMessage = validation.userMessage
                        )
                    }
                    return@launch
                }

                is VideoValidationResult.Valid -> {
                    val metadata = validation.metadata
                    _uiState.update {
                        it.copy(
                            currentScreen = AppScreenRoute.Processing,
                            processingThumbnail = metadata.previewThumbnailFile,
                            processingProgress = 0.35f,
                            isAutoTrimmingLongVideo = metadata.wasAutoTrimmed
                        )
                    }

                    val result = mediaProcessor.processVideoPreservingAudio(
                        metadata = metadata,
                        preserveOriginalResolution = _uiState.value.settings.preserveOriginalResolution,
                        onProgressChanged = { progress ->
                            _uiState.update { it.copy(processingProgress = progress) }
                        }
                    )

                    result.fold(
                        onSuccess = { output ->
                            val previewItem = ActivePreviewItem.fromProcessed(output)
                            val trimNotice = if (output.wasAutoTrimmed) {
                                val origSec = String.format(
                                    Locale("pt", "BR"),
                                    "%.1f",
                                    output.originalDurationMs / 1000.0
                                )
                                "Vídeo de ${origSec}s cortado automaticamente para os primeiros 20 segundos."
                            } else {
                                null
                            }

                            _uiState.update {
                                it.copy(
                                    currentScreen = AppScreenRoute.Preview,
                                    activePreview = previewItem,
                                    processingThumbnail = null,
                                    processingProgress = 1f,
                                    infoBannerMessage = trimNotice
                                )
                            }
                        },
                        onFailure = { error ->
                            _uiState.update {
                                it.copy(
                                    currentScreen = AppScreenRoute.Home,
                                    processingThumbnail = null,
                                    errorMessage = error.message
                                        ?: MediaProcessor.ERROR_PROCESSING_FAILED
                                )
                            }
                        }
                    )
                }
            }
        }
    }

    fun cancelProcessing() {
        activeProcessingJob?.cancel()
        _uiState.update {
            it.copy(
                currentScreen = AppScreenRoute.Home,
                processingThumbnail = null,
                processingProgress = 0f,
                isAutoTrimmingLongVideo = false
            )
        }
    }

    fun saveCurrentPreviewToLibrary() {
        val current = _uiState.value.activePreview ?: return
        if (current.isAlreadySavedInLibrary) {
            _uiState.update {
                it.copy(infoBannerMessage = "Esta figurinha já está salva na sua biblioteca.")
            }
            return
        }

        viewModelScope.launch {
            val result = repository.saveProcessedStickerToLibrary(
                tempVideoFile = current.videoFile,
                tempThumbnailFile = current.thumbnailFile,
                durationMs = current.durationMs,
                width = current.width,
                height = current.height,
                hasAudio = current.hasAudio,
                audioCodec = current.audioCodec,
                videoCodec = current.videoCodec,
                alsoExportToGallery = true
            )

            result.fold(
                onSuccess = { savedEntity ->
                    _uiState.update {
                        it.copy(
                            activePreview = ActivePreviewItem.fromEntity(savedEntity),
                            infoBannerMessage = "Figurinha salva na biblioteca e pronta para o WhatsApp."
                        )
                    }
                },
                onFailure = {
                    _uiState.update {
                        it.copy(errorMessage = VideoValidator.ERROR_NO_STORAGE_SPACE)
                    }
                }
            )
        }
    }

    fun addCurrentPreviewToWhatsApp() {
        val current = _uiState.value.activePreview ?: return
        if (_uiState.value.isPreparingWhatsAppPack) return

        viewModelScope.launch {
            _uiState.update { it.copy(isPreparingWhatsAppPack = true, errorMessage = null) }

            val readyEntity = if (!current.isAlreadySavedInLibrary) {
                val saveRes = repository.saveProcessedStickerToLibrary(
                    tempVideoFile = current.videoFile,
                    tempThumbnailFile = current.thumbnailFile,
                    durationMs = current.durationMs,
                    width = current.width,
                    height = current.height,
                    hasAudio = current.hasAudio,
                    audioCodec = current.audioCodec,
                    videoCodec = current.videoCodec,
                    alsoExportToGallery = true
                )
                saveRes.getOrNull()?.also { saved ->
                    _uiState.update { it.copy(activePreview = ActivePreviewItem.fromEntity(saved)) }
                }
            } else {
                val id = current.savedEntityId
                if (id != null) {
                    repository.getStickerById(id)?.let { repository.ensureStickerHasWebp(it) }
                } else {
                    null
                }
            }

            _uiState.update { it.copy(isPreparingWhatsAppPack = false) }

            if (readyEntity == null) {
                _uiState.update {
                    it.copy(errorMessage = MediaProcessor.ERROR_PROCESSING_FAILED)
                }
                return@launch
            }

            val target = _uiState.value.settings.whatsAppTarget
            when (val dispatch = WhatsAppIntegrationManager.addStickerPackToWhatsApp(app, target)) {
                is ShareDispatchResult.Dispatched -> Unit
                is ShareDispatchResult.Error -> {
                    _uiState.update { it.copy(errorMessage = dispatch.userMessage) }
                }
            }
        }
    }

    fun sendCurrentPreviewWithAudioToWhatsApp() {
        val current = _uiState.value.activePreview ?: return
        val target = _uiState.value.settings.whatsAppTarget
        when (val result = WhatsAppIntegrationManager.sendVideoWithAudioToWhatsApp(
            app,
            current.videoFile,
            target
        )) {
            is ShareDispatchResult.Dispatched -> {
                _uiState.update { it.copy(errorMessage = null) }
            }
            is ShareDispatchResult.Error -> {
                _uiState.update { it.copy(errorMessage = result.userMessage) }
            }
        }
    }

    fun shareCurrentPreview() {
        val current = _uiState.value.activePreview ?: return
        dispatchSystemShare(current.videoFile)
    }

    fun addSavedStickerToWhatsAppPack(entity: StickerEntity) {
        viewModelScope.launch {
            _uiState.update { it.copy(isPreparingWhatsAppPack = true) }
            repository.ensureStickerHasWebp(entity)
            _uiState.update { it.copy(isPreparingWhatsAppPack = false) }

            val target = _uiState.value.settings.whatsAppTarget
            when (val result = WhatsAppIntegrationManager.addStickerPackToWhatsApp(app, target)) {
                is ShareDispatchResult.Dispatched -> Unit
                is ShareDispatchResult.Error -> {
                    _uiState.update { it.copy(errorMessage = result.userMessage) }
                }
            }
        }
    }

    fun shareSavedStickerSystem(entity: StickerEntity) {
        dispatchSystemShare(File(entity.videoFilePath))
    }

    private fun dispatchSystemShare(file: File) {
        when (val result = WhatsAppIntegrationManager.shareViaSystemChooser(app, file)) {
            is ShareDispatchResult.Dispatched -> {
                _uiState.update { it.copy(errorMessage = null) }
            }
            is ShareDispatchResult.Error -> {
                _uiState.update { it.copy(errorMessage = result.userMessage) }
            }
        }
    }

    fun openSavedStickerInPreview(entity: StickerEntity) {
        val file = File(entity.videoFilePath)
        if (!file.exists()) {
            _uiState.update {
                it.copy(errorMessage = VideoValidator.ERROR_CORRUPTED_FILE)
            }
            return
        }
        _uiState.update {
            it.copy(
                currentScreen = AppScreenRoute.Preview,
                activePreview = ActivePreviewItem.fromEntity(entity)
            )
        }
    }

    fun deleteSticker(entity: StickerEntity) {
        viewModelScope.launch {
            repository.deleteSticker(entity)
            _uiState.update {
                it.copy(infoBannerMessage = "Figurinha excluída da biblioteca.")
            }
        }
    }

    fun navigateTo(route: AppScreenRoute) {
        if (route == AppScreenRoute.Settings || route == AppScreenRoute.Home) {
            val updatedSupport = WhatsAppIntegrationManager.inspectWhatsAppSupport(app)
            _uiState.update {
                it.copy(currentScreen = route, whatsAppSupport = updatedSupport)
            }
        } else {
            _uiState.update { it.copy(currentScreen = route) }
        }
    }

    fun updateWhatsAppTarget(target: WhatsAppTarget) {
        viewModelScope.launch { preferences.setWhatsAppTarget(target) }
    }

    fun updateAutoPlayWithSound(enabled: Boolean) {
        viewModelScope.launch { preferences.setAutoPlayWithSound(enabled) }
    }

    fun updatePreserveResolution(enabled: Boolean) {
        viewModelScope.launch { preferences.setPreserveOriginalResolution(enabled) }
    }

    fun clearCache() {
        viewModelScope.launch {
            repository.clearTemporaryCache()
            _uiState.update {
                it.copy(infoBannerMessage = "Arquivos temporários removidos com sucesso.")
            }
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun dismissInfoBanner() {
        _uiState.update { it.copy(infoBannerMessage = null) }
    }
}
