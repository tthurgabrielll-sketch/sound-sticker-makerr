package br.com.soundstickermaker.stickers

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.UriMatcher
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import br.com.soundstickermaker.data.local.AppDatabase
import br.com.soundstickermaker.data.local.StickerEntity
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.FileNotFoundException

/**
 * ContentProvider oficial exigido pelo protocolo de Figurinhas de Terceiros do WhatsApp
 * (com.whatsapp.intent.action.ENABLE_STICKER_PACK), idêntico ao usado pelo Sticker.ly.
 */
class StickerContentProvider : ContentProvider() {

    companion object {
        const val PACK_IDENTIFIER = "sound_sticker_maker_pack_v1"
        const val PACK_NAME = "Sound Sticker Maker"
        const val PACK_PUBLISHER = "Sound Sticker Maker"
        const val TRAY_ICON_FILE_NAME = "tray_icon.png"

        private const val CODE_METADATA = 1
        private const val CODE_METADATA_SINGLE = 2
        private const val CODE_STICKERS = 3
        private const val CODE_STICKERS_ASSET = 4

        private val METADATA_COLUMNS = arrayOf(
            "sticker_pack_identifier",
            "sticker_pack_name",
            "sticker_pack_publisher",
            "sticker_pack_icon",
            "android_play_store_link",
            "ios_app_download_link",
            "publisher_email",
            "publisher_website",
            "privacy_policy_website",
            "license_agreement_website",
            "image_data_version",
            "avoid_cache",
            "animated_sticker_pack"
        )

        private val STICKERS_COLUMNS = arrayOf(
            "sticker_file_name",
            "sticker_emoji"
        )
    }

    private lateinit var uriMatcher: UriMatcher
    private lateinit var authority: String

    override fun onCreate(): Boolean {
        val ctx = context ?: return false
        authority = "${ctx.packageName}.stickercontentprovider"
        uriMatcher = UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(authority, "metadata", CODE_METADATA)
            addURI(authority, "metadata/*", CODE_METADATA_SINGLE)
            addURI(authority, "stickers/*", CODE_STICKERS)
            addURI(authority, "stickers_asset/*/*", CODE_STICKERS_ASSET)
        }
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        val ctx = context ?: return null
        ensureBaseStickerAssetsExist()

        return when (uriMatcher.match(uri)) {
            CODE_METADATA, CODE_METADATA_SINGLE -> buildMetadataCursor(ctx)
            CODE_STICKERS -> buildStickersCursor(ctx)
            else -> null
        }
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        val ctx = context ?: throw FileNotFoundException("Contexto indisponível")
        if (uriMatcher.match(uri) != CODE_STICKERS_ASSET) {
            throw FileNotFoundException("URI inválida: $uri")
        }

        ensureBaseStickerAssetsExist()
        val fileName = uri.lastPathSegment ?: throw FileNotFoundException("Arquivo não informado")
        val stickersDir = File(ctx.filesDir, "stickers")
        val targetFile = File(stickersDir, fileName)

        if (!targetFile.exists() || targetFile.length() == 0L) {
            throw FileNotFoundException("Asset não encontrado: ${targetFile.absolutePath}")
        }

        val pfd = ParcelFileDescriptor.open(targetFile, ParcelFileDescriptor.MODE_READ_ONLY)
        return AssetFileDescriptor(pfd, 0L, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    override fun getType(uri: Uri): String? {
        return when (uriMatcher.match(uri)) {
            CODE_METADATA -> "vnd.android.cursor.dir/vnd.$authority.metadata"
            CODE_METADATA_SINGLE -> "vnd.android.cursor.item/vnd.$authority.metadata"
            CODE_STICKERS -> "vnd.android.cursor.dir/vnd.$authority.stickers"
            CODE_STICKERS_ASSET -> {
                if (uri.lastPathSegment?.endsWith(".png", ignoreCase = true) == true) {
                    "image/png"
                } else {
                    "image/webp"
                }
            }
            else -> null
        }
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0

    private fun buildMetadataCursor(ctx: Context): Cursor {
        val entities: List<StickerEntity> = runBlocking<List<StickerEntity>> {
            AppDatabase.getInstance(ctx).stickerDao().getAllStickersSync()
        }
        val latestTimestamp = entities.maxOfOrNull { it.createdAtEpochMs } ?: 1L
        val versionString = "${entities.size}_$latestTimestamp"

        val cursor = MatrixCursor(METADATA_COLUMNS)
        cursor.addRow(
            arrayOf<Any>(
                PACK_IDENTIFIER,
                PACK_NAME,
                PACK_PUBLISHER,
                TRAY_ICON_FILE_NAME,
                "",
                "",
                "",
                "",
                "",
                "",
                versionString,
                1,
                1
            )
        )
        return cursor
    }

    private fun buildStickersCursor(ctx: Context): Cursor {
        val entities: List<StickerEntity> = runBlocking<List<StickerEntity>> {
            AppDatabase.getInstance(ctx).stickerDao().getAllStickersSync()
        }

        val validWebpNames = mutableListOf<String>()
        val limitedEntities: List<StickerEntity> = entities.take(30)
        for (entity: StickerEntity in limitedEntities) {
            val webpPath: String = entity.webpFilePath
            if (webpPath.isNotBlank()) {
                val webpFile = File(webpPath)
                if (webpFile.exists() && webpFile.length() > 0L) {
                    validWebpNames.add(webpFile.name)
                }
            }
        }

        var fillerIndex = 1
        while (validWebpNames.size < 3 && fillerIndex <= 3) {
            val fillerName = "filler_sticker_$fillerIndex.webp"
            val fillerFile = File(File(ctx.filesDir, "stickers"), fillerName)
            if (fillerFile.exists() && fillerFile.length() > 0L) {
                validWebpNames.add(fillerName)
            }
            fillerIndex++
        }

        val cursor = MatrixCursor(STICKERS_COLUMNS)
        for (fileName in validWebpNames) {
            cursor.addRow(arrayOf<Any>(fileName, "\uD83D\uDD0A,\uD83C\uDFB5"))
        }
        return cursor
    }

    private fun ensureBaseStickerAssetsExist() {
        val ctx = context ?: return
        val stickersDir = File(ctx.filesDir, "stickers").apply {
            if (!exists()) mkdirs()
        }
        val trayFile = File(stickersDir, TRAY_ICON_FILE_NAME)
        if (!trayFile.exists() || trayFile.length() == 0L) {
            AnimatedWebpEncoder.generateTrayIconPng(trayFile)
        }
        for (i in 1..3) {
            val fillerFile = File(stickersDir, "filler_sticker_$i.webp")
            if (!fillerFile.exists() || fillerFile.length() == 0L) {
                AnimatedWebpEncoder.generateBrandedFillerWebp(fillerFile, variantIndex = i)
            }
        }
    }
}
