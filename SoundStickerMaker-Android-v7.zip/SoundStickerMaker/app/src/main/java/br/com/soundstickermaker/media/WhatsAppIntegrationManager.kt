package br.com.soundstickermaker.media

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.FileProvider
import br.com.soundstickermaker.data.preferences.WhatsAppTarget
import br.com.soundstickermaker.stickers.StickerContentProvider
import java.io.File

data class WhatsAppSupportStatus(
    val isStandardInstalled: Boolean,
    val isBusinessInstalled: Boolean,
    val hasNativeAudioStickerApi: Boolean,
    val technicalExplanation: String
) {
    val isAnyWhatsAppInstalled: Boolean
        get() = isStandardInstalled || isBusinessInstalled
}

sealed interface ShareDispatchResult {
    data object Dispatched : ShareDispatchResult
    data class Error(val userMessage: String) : ShareDispatchResult
}

object WhatsAppIntegrationManager {

    const val PKG_WHATSAPP_STANDARD = "com.whatsapp"
    const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"

    const val ERROR_WHATSAPP_NOT_INSTALLED =
        "O WhatsApp não está instalado neste dispositivo. Instale o WhatsApp ou use o botão COMPARTILHAR."
    const val ERROR_SHARE_FAILED =
        "Não foi possível abrir o WhatsApp para adicionar a figurinha. Tente novamente."
    const val INFO_NATIVE_FORMAT_LIMITATION =
        "O botão ADICIONAR AO WHATSAPP importa a figurinha direto na bandeja do WhatsApp (como no Sticker.ly). Para enviar o clipe com áudio original na conversa, use ENVIAR COM ÁUDIO."

    fun inspectWhatsAppSupport(context: Context): WhatsAppSupportStatus {
        val pm = context.packageManager
        val standardInstalled = isPackageInstalled(pm, PKG_WHATSAPP_STANDARD)
        val businessInstalled = isPackageInstalled(pm, PKG_WHATSAPP_BUSINESS)

        val stickerPackProbe = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK")
        val resolvedReceivers = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                stickerPackProbe,
                PackageManager.ResolveInfoFlags.of(0L)
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(stickerPackProbe, 0)
        }
        val nativeStickerApiAvailable = resolvedReceivers.isNotEmpty()

        val explanation = if (nativeStickerApiAvailable) {
            "Protocolo oficial de pacotes de figurinhas do WhatsApp ativo (StickerContentProvider 512x512 WebP animado)."
        } else {
            "Instale ou atualize o WhatsApp para importar pacotes diretamente na aba de figurinhas."
        }

        return WhatsAppSupportStatus(
            isStandardInstalled = standardInstalled,
            isBusinessInstalled = businessInstalled,
            hasNativeAudioStickerApi = nativeStickerApiAvailable,
            technicalExplanation = explanation
        )
    }

    /**
     * Abre o diálogo nativo do WhatsApp ("Deseja adicionar Sound Sticker Maker ao WhatsApp?")
     * exatamente como o Sticker.ly, adicionando a figurinha à bandeja oficial do WhatsApp.
     */
    fun addStickerPackToWhatsApp(
        context: Context,
        preferredTarget: WhatsAppTarget
    ): ShareDispatchResult {
        val status = inspectWhatsAppSupport(context)
        if (!status.isAnyWhatsAppInstalled) {
            return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)
        }

        val targetPackage = resolveTargetPackage(status, preferredTarget)
            ?: return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)

        return try {
            val intent = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK").apply {
                putExtra("sticker_pack_id", StickerContentProvider.PACK_IDENTIFIER)
                putExtra(
                    "sticker_pack_authority",
                    "${context.packageName}.stickercontentprovider"
                )
                putExtra("sticker_pack_name", StickerContentProvider.PACK_NAME)
                setPackage(targetPackage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ShareDispatchResult.Dispatched
        } catch (_: Exception) {
            ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }
    }

    /**
     * Envia o arquivo MP4 curto de até 20 segundos preservando 100% do áudio original no chat.
     */
    fun sendVideoWithAudioToWhatsApp(
        context: Context,
        videoFile: File,
        preferredTarget: WhatsAppTarget
    ): ShareDispatchResult {
        if (!videoFile.exists() || videoFile.length() == 0L) {
            return ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }

        val status = inspectWhatsAppSupport(context)
        if (!status.isAnyWhatsAppInstalled) {
            return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)
        }

        val targetPackage = resolveTargetPackage(status, preferredTarget)
            ?: return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)

        return try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                videoFile
            )

            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                clipData = ClipData.newRawUri("Sound Sticker", contentUri)
                setPackage(targetPackage)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(sendIntent)
            ShareDispatchResult.Dispatched
        } catch (_: Exception) {
            ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }
    }

    fun shareViaSystemChooser(
        context: Context,
        videoFile: File
    ): ShareDispatchResult {
        if (!videoFile.exists() || videoFile.length() == 0L) {
            return ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }

        return try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                videoFile
            )

            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                clipData = ClipData.newRawUri("Sound Sticker", contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(
                sendIntent,
                "Compartilhar figurinha com som"
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(chooser)
            ShareDispatchResult.Dispatched
        } catch (_: Exception) {
            ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }
    }

    private fun resolveTargetPackage(
        status: WhatsAppSupportStatus,
        preferredTarget: WhatsAppTarget
    ): String? {
        return when (preferredTarget) {
            WhatsAppTarget.STANDARD -> {
                if (status.isStandardInstalled) PKG_WHATSAPP_STANDARD
                else if (status.isBusinessInstalled) PKG_WHATSAPP_BUSINESS
                else null
            }
            WhatsAppTarget.BUSINESS -> {
                if (status.isBusinessInstalled) PKG_WHATSAPP_BUSINESS
                else if (status.isStandardInstalled) PKG_WHATSAPP_STANDARD
                else null
            }
            WhatsAppTarget.AUTO -> {
                if (status.isStandardInstalled) PKG_WHATSAPP_STANDARD
                else if (status.isBusinessInstalled) PKG_WHATSAPP_BUSINESS
                else null
            }
        }
    }

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, 0)
            }
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }
}
