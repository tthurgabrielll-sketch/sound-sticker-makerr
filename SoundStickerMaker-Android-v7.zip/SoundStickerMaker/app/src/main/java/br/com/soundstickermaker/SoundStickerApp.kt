package br.com.soundstickermaker

import android.app.Application
import br.com.soundstickermaker.data.local.AppDatabase
import br.com.soundstickermaker.data.preferences.UserPreferencesRepository
import br.com.soundstickermaker.data.repository.StickerRepository

class SoundStickerApp : Application() {

    val database: AppDatabase by lazy {
        AppDatabase.getInstance(this)
    }

    val stickerRepository: StickerRepository by lazy {
        StickerRepository(
            context = this,
            stickerDao = database.stickerDao()
        )
    }

    val preferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(this)
    }
}
