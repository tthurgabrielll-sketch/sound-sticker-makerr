package br.com.soundstickermaker.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0D1117)
val DarkSurface = Color(0xFF161B22)
val DarkSurfaceVariant = Color(0xFF21262D)
val EmeraldPrimary = Color(0xFF25D366)
val EmeraldOnPrimary = Color(0xFF042611)
val EmeraldContainer = Color(0xFF0F3D22)
val OnEmeraldContainer = Color(0xFFA7F3C3)
val CyanSecondary = Color(0xFF58A6FF)
val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val ErrorRed = Color(0xFFF85149)
val ErrorContainerDark = Color(0xFF3D1418)

private val AppDarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = EmeraldOnPrimary,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = OnEmeraldContainer,
    secondary = CyanSecondary,
    onSecondary = Color(0xFF051D3B),
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    error = ErrorRed,
    onError = Color(0xFF330606),
    errorContainer = ErrorContainerDark,
    onErrorContainer = Color(0xFFFFDAD6),
    outline = Color(0xFF30363D)
)

@Composable
fun SoundStickerMakerTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AppDarkColorScheme,
        typography = AppTypography,
        content = content
    )
}
