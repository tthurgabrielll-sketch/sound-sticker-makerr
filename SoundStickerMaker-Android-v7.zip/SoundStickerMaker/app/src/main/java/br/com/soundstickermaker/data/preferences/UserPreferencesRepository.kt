package br.com.soundstickermaker.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "sound_sticker_settings")

enum class WhatsAppTarget(val label: String, val packageName: String?) {
    AUTO("Detecção Automática (Padrão ou Business)", null),
    STANDARD("WhatsApp Padrão (com.whatsapp)", "com.whatsapp"),
    BUSINESS("WhatsApp Business (com.whatsapp.w4b)", "com.whatsapp.w4b")
}

data class UserSettings(
    val whatsAppTarget: WhatsAppTarget = WhatsAppTarget.AUTO,
    val autoPlayWithSound: Boolean = true,
    val preserveOriginalResolution: Boolean = true
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val WHATSAPP_TARGET = stringPreferencesKey("whatsapp_target")
        val AUTO_PLAY_SOUND = booleanPreferencesKey("auto_play_sound")
        val PRESERVE_RESOLUTION = booleanPreferencesKey("preserve_resolution")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        val targetName = prefs[Keys.WHATSAPP_TARGET] ?: WhatsAppTarget.AUTO.name
        val target = runCatching { WhatsAppTarget.valueOf(targetName) }
            .getOrDefault(WhatsAppTarget.AUTO)
        UserSettings(
            whatsAppTarget = target,
            autoPlayWithSound = prefs[Keys.AUTO_PLAY_SOUND] ?: true,
            preserveOriginalResolution = prefs[Keys.PRESERVE_RESOLUTION] ?: true
        )
    }

    suspend fun setWhatsAppTarget(target: WhatsAppTarget) {
        context.dataStore.edit { it[Keys.WHATSAPP_TARGET] = target.name }
    }

    suspend fun setAutoPlayWithSound(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_PLAY_SOUND] = enabled }
    }

    suspend fun setPreserveOriginalResolution(enabled: Boolean) {
        context.dataStore.edit { it[Keys.PRESERVE_RESOLUTION] = enabled }
    }
}
