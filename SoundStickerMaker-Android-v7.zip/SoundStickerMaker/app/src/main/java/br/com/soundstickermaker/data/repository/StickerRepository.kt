package br.com.soundstickermaker.data.repository

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import br.com.soundstickermaker.data.local.StickerDao
import br.com.soundstickermaker.data.local.StickerEntity
import br.com.soundstickermaker.stickers.AnimatedWebpEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StickerRepository(
    private val context: Context,
    private val stickerDao: StickerDao
) {

    fun observeAllStickers(): Flow<List<StickerEntity>> = stickerDao.observeAllStickers()

    fun observeRecentStickers(limit: Int = 6): Flow<List<StickerEntity>> =
        stickerDao.observeRecentStickers(limit)

    suspend fun getStickerById(id: Long): StickerEntity? = stickerDao.getStickerById(id)

    suspend fun saveProcessedStickerToLibrary(
        tempVideoFile: File,
        tempThumbnailFile: File?,
        durationMs: Long,
        width: Int,
        height: Int,
        hasAudio: Boolean,
        audioCodec: String,
        videoCodec: String,
        alsoExportToGallery: Boolean = true
    ): Result<StickerEntity> = withContext(Dispatchers.IO) {
        runCatching {
            val stickersDir = File(context.filesDir, "stickers").apply {
                if (!exists()) mkdirs()
            }

            val timestamp = System.currentTimeMillis()
            val formattedDate = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.forLanguageTag("pt-BR"))
                .format(Date(timestamp))

            val permanentVideo = File(stickersDir, "sound_sticker_$timestamp.mp4")
            val permanentWebp = File(stickersDir, "sticker_$timestamp.webp")
            val permanentThumb = File(stickersDir, "thumb_$timestamp.jpg")

            tempVideoFile.copyTo(permanentVideo, overwrite = true)

            if (tempThumbnailFile != null &&
                tempThumbnailFile.exists() &&
                tempThumbnailFile.name.endsWith(".jpg", ignoreCase = true)
            ) {
                tempThumbnailFile.copyTo(permanentThumb, overwrite = true)
            } else {
                generateJpegThumbnailFromVideo(permanentVideo, permanentThumb)
            }

            val webpCreated = AnimatedWebpEncoder.encodeVideoToAnimatedWebp(
                videoFile = permanentVideo,
                durationMs = durationMs,
                outputWebpFile = permanentWebp,
                fallbackThumbnailFile = permanentThumb
            )

            if (alsoExportToGallery) {
                exportVideoToPublicGallery(permanentVideo)
            }

            val entity = StickerEntity(
                title = "Figurinha $formattedDate",
                videoFilePath = permanentVideo.absolutePath,
                webpFilePath = if (webpCreated) permanentWebp.absolutePath else "",
                thumbnailFilePath = permanentThumb.absolutePath,
                durationMs = durationMs,
                fileSizeBytes = permanentVideo.length(),
                width = width,
                height = height,
                hasAudio = hasAudio,
                audioCodec = audioCodec,
                videoCodec = videoCodec,
                createdAtEpochMs = timestamp
            )

            val insertedId = stickerDao.insertSticker(entity)
            entity.copy(id = insertedId)
        }
    }

    suspend fun ensureStickerHasWebp(entity: StickerEntity): StickerEntity =
        withContext(Dispatchers.IO) {
            if (entity.webpFilePath.isNotBlank() && File(entity.webpFilePath).exists()) {
                return@withContext entity
            }
            val stickersDir = File(context.filesDir, "stickers").apply {
                if (!exists()) mkdirs()
            }
            val webpFile = File(stickersDir, "sticker_${entity.createdAtEpochMs}.webp")
            val ok = AnimatedWebpEncoder.encodeVideoToAnimatedWebp(
                videoFile = File(entity.videoFilePath),
                durationMs = entity.durationMs,
                outputWebpFile = webpFile,
                fallbackThumbnailFile = File(entity.thumbnailFilePath)
            )
            if (ok) {
                val updated = entity.copy(webpFilePath = webpFile.absolutePath)
                stickerDao.insertSticker(updated)
                updated
            } else {
                entity
            }
        }

    suspend fun deleteSticker(sticker: StickerEntity) = withContext(Dispatchers.IO) {
        runCatching { File(sticker.videoFilePath).delete() }
        if (sticker.webpFilePath.isNotBlank()) {
            runCatching { File(sticker.webpFilePath).delete() }
        }
        runCatching { File(sticker.thumbnailFilePath).delete() }
        stickerDao.deleteSticker(sticker)
    }

    suspend fun clearTemporaryCache() = withContext(Dispatchers.IO) {
        val cacheDir = File(context.cacheDir, "processed")
        if (cacheDir.exists()) {
            cacheDir.listFiles()?.forEach { it.delete() }
        }
    }

    private fun generateJpegThumbnailFromVideo(videoFile: File, targetJpg: File) {
        runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(videoFile.absolutePath)
                val bitmap = retriever.getFrameAtTime(
                    0L,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                ) ?: return
                FileOutputStream(targetJpg).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
                }
                bitmap.recycle()
            } finally {
                retriever.release()
            }
        }
    }

    private fun exportVideoToPublicGallery(sourceFile: File) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        runCatching {
            val resolver = context.contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, sourceFile.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_MOVIES}/SoundStickerMaker"
                )
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }

            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, contentValues) ?: return
            resolver.openOutputStream(itemUri)?.use { out ->
                sourceFile.inputStream().use { input ->
                    input.copyTo(out)
                }
            }

            contentValues.clear()
            contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(itemUri, contentValues, null, null)
        }
    }
}
