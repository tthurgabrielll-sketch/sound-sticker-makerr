package br.com.soundstickermaker

import br.com.soundstickermaker.media.VideoValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoValidatorTest {

    @Test
    fun `mantem duracao integral de videos ate 20 segundos`() {
        assertEquals(1_000L, VideoValidator.computeTargetClipDurationMs(1_000L))
        assertEquals(12_500L, VideoValidator.computeTargetClipDurationMs(12_500L))
        assertEquals(20_000L, VideoValidator.computeTargetClipDurationMs(20_000L))
        assertFalse(VideoValidator.shouldAutoTrim(20_000L))
    }

    @Test
    fun `corta automaticamente para 20 segundos quando video ultrapassa limite`() {
        assertTrue(VideoValidator.shouldAutoTrim(20_001L))
        assertTrue(VideoValidator.shouldAutoTrim(65_000L))
        assertEquals(20_000L, VideoValidator.computeTargetClipDurationMs(20_001L))
        assertEquals(20_000L, VideoValidator.computeTargetClipDurationMs(65_000L))
    }

    @Test
    fun `retorna zero para duracao invalida`() {
        assertEquals(0L, VideoValidator.computeTargetClipDurationMs(0L))
        assertEquals(0L, VideoValidator.computeTargetClipDurationMs(-100L))
    }
}
