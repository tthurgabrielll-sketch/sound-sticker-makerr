package br.com.soundstickermaker.media

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.FileProvider
import br.com.soundstickermaker.data.preferences.WhatsAppTarget
import java.io.File

data class WhatsAppSupportStatus(
    val isStandardInstalled: Boolean,
    val isBusinessInstalled: Boolean,
    val hasNativeAudioStickerApi: Boolean,
    val technicalExplanation: String
) {
    val isAnyWhatsAppInstalled: Boolean
        get() = isStandardInstalled || isBusinessInstalled
}

sealed interface ShareDispatchResult {
    data object Dispatched : ShareDispatchResult
    data class Error(val userMessage: String) : ShareDispatchResult
}

object WhatsAppIntegrationManager {

    const val PKG_WHATSAPP_STANDARD = "com.whatsapp"
    const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"

    const val ERROR_WHATSAPP_NOT_INSTALLED =
        "O WhatsApp não está instalado neste dispositivo. Instale o WhatsApp ou use o botão COMPARTILHAR."
    const val ERROR_SHARE_FAILED =
        "Não foi possível iniciar o compartilhamento do arquivo. Verifique as permissões e tente novamente."
    const val INFO_NATIVE_FORMAT_LIMITATION =
        "Nota oficial: o formato de figurinhas nativas do WhatsApp (WebP) não suporta faixas de áudio. Este arquivo será enviado preservando o som original como clipe MP4 curto."

    fun inspectWhatsAppSupport(context: Context): WhatsAppSupportStatus {
        val pm = context.packageManager
        val standardInstalled = isPackageInstalled(pm, PKG_WHATSAPP_STANDARD)
        val businessInstalled = isPackageInstalled(pm, PKG_WHATSAPP_BUSINESS)

        val audioStickerProbe = Intent("com.whatsapp.intent.action.ENABLE_AUDIO_STICKER_PACK")
        val resolvedReceivers = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                audioStickerProbe,
                PackageManager.ResolveInfoFlags.of(0L)
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(audioStickerProbe, 0)
        }
        val nativeAudioStickerAvailable = resolvedReceivers.isNotEmpty()

        val explanation = if (nativeAudioStickerAvailable) {
            "API oficial de figurinhas com som detectada no dispositivo."
        } else {
            "A especificação oficial do WhatsApp (WebP 512x512) não permite faixas de áudio em figurinhas estáticas ou animadas. O Sound Sticker Maker utiliza o envio direto oficial em MP4 (H.264 + AAC) para preservar 100% do som original."
        }

        return WhatsAppSupportStatus(
            isStandardInstalled = standardInstalled,
            isBusinessInstalled = businessInstalled,
            hasNativeAudioStickerApi = nativeAudioStickerAvailable,
            technicalExplanation = explanation
        )
    }

    fun sendToWhatsApp(
        context: Context,
        videoFile: File,
        preferredTarget: WhatsAppTarget
    ): ShareDispatchResult {
        if (!videoFile.exists() || videoFile.length() == 0L) {
            return ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }

        val status = inspectWhatsAppSupport(context)
        if (!status.isAnyWhatsAppInstalled) {
            return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)
        }

        val targetPackage = resolveTargetPackage(status, preferredTarget)
            ?: return ShareDispatchResult.Error(ERROR_WHATSAPP_NOT_INSTALLED)

        return try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                videoFile
            )

            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                setPackage(targetPackage)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(sendIntent)
            ShareDispatchResult.Dispatched
        } catch (_: Exception) {
            ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }
    }

    fun shareViaSystemChooser(
        context: Context,
        videoFile: File
    ): ShareDispatchResult {
        if (!videoFile.exists() || videoFile.length() == 0L) {
            return ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }

        return try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                videoFile
            )

            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(
                sendIntent,
                "Compartilhar figurinha com som"
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(chooser)
            ShareDispatchResult.Dispatched
        } catch (_: Exception) {
            ShareDispatchResult.Error(ERROR_SHARE_FAILED)
        }
    }

    private fun resolveTargetPackage(
        status: WhatsAppSupportStatus,
        preferredTarget: WhatsAppTarget
    ): String? {
        return when (preferredTarget) {
            WhatsAppTarget.STANDARD -> {
                if (status.isStandardInstalled) PKG_WHATSAPP_STANDARD
                else if (status.isBusinessInstalled) PKG_WHATSAPP_BUSINESS
                else null
            }
            WhatsAppTarget.BUSINESS -> {
                if (status.isBusinessInstalled) PKG_WHATSAPP_BUSINESS
                else if (status.isStandardInstalled) PKG_WHATSAPP_STANDARD
                else null
            }
            WhatsAppTarget.AUTO -> {
                if (status.isStandardInstalled) PKG_WHATSAPP_STANDARD
                else if (status.isBusinessInstalled) PKG_WHATSAPP_BUSINESS
                else null
            }
        }
    }

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, 0)
            }
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }
}
