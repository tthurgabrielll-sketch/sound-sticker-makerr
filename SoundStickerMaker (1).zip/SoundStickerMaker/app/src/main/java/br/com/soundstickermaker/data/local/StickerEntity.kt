package br.com.soundstickermaker.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sound_stickers")
data class StickerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val videoFilePath: String,
    val thumbnailFilePath: String,
    val durationMs: Long,
    val fileSizeBytes: Long,
    val width: Int,
    val height: Int,
    val hasAudio: Boolean,
    val audioCodec: String,
    val videoCodec: String,
    val createdAtEpochMs: Long
)
