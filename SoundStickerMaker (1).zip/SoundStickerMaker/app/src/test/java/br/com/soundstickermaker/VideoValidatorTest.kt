package br.com.soundstickermaker

import br.com.soundstickermaker.media.VideoValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoValidatorTest {

    @Test
    fun `aceita video curto de 1 segundo`() {
        assertTrue(VideoValidator.isDurationAllowed(1_000L))
    }

    @Test
    fun `aceita video de 7 segundos e meio`() {
        assertTrue(VideoValidator.isDurationAllowed(7_500L))
    }

    @Test
    fun `aceita video com exatamente 10 segundos`() {
        assertTrue(VideoValidator.isDurationAllowed(10_000L))
    }

    @Test
    fun `rejeita video com 10 segundos e 1 milissegundo`() {
        assertFalse(VideoValidator.isDurationAllowed(10_001L))
    }

    @Test
    fun `rejeita video de 15 segundos`() {
        assertFalse(VideoValidator.isDurationAllowed(15_000L))
    }

    @Test
    fun `rejeita video com duracao zero ou negativa`() {
        assertFalse(VideoValidator.isDurationAllowed(0L))
        assertFalse(VideoValidator.isDurationAllowed(-500L))
    }

    @Test
    fun `mensagem de erro de duracao corresponde exatamente ao requisito`() {
        assertEquals(
            "Este vídeo ultrapassa o limite de 10 segundos. Escolha um vídeo mais curto.",
            VideoValidator.ERROR_EXCEEDS_DURATION
        )
    }
}
